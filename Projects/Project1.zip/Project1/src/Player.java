
public class Player {

    String name;
    int wins;
    int losses;
    int gamesPlayed;

    public void sendPlay(){
        
    }

}

