
public class TicTacToe {

    public void play(Player player1, Player player2) {
        System.out.println("\n****Welcome to Tic Tac Toe!****");
        System.out.println(player1.name + " vs " + player2.name);
    }

}
