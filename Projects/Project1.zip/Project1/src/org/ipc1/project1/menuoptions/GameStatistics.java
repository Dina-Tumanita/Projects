package org.ipc1.project1.menuoptions;

public class GameStatistics {

    public void showStats(){
        
        System.out.println("Game Stats");
                
    }

}
