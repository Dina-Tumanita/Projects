package org.ipc1.project1;

public class Project{
    
    public static void main(String []args) {
        // Menu menu = new Menu();
        // menu.play();
        new Menu().play();
           
    }


}