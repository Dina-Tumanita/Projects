package org.ipc1.project1.games.HangMan;

import java.util.Scanner;

import org.ipc1.project1.utils.Player;
import org.ipc1.project1.utils.Reader;

public class HangedMan {
    private TurnHM turn = new TurnHM();
    private Reader read = new Reader();
    private Scanner scanner = new Scanner(System.in);
    
    private int playerCounter = 1;
    private String secretWord = "";
    private char[] secretWordarray;
    private char[] guessingWordarray;
    private int hangmanParts;
    private boolean gaming;
    private String[] hangedMan = new String[6]; 
    

    
    public void startGame(Player player1, Player player2) {   
        player1.gamesPlayed++;
        player2.gamesPlayed++;
        hangmanParts = 8; 
        gaming = true;
        hangedMan[0] = ("");                 //rope
        hangedMan[1] = ("");                 //head
        hangedMan[2] = ("");                 //arms  and body
        hangedMan[3] = ("");                 //body
        hangedMan[4] = ("");                 //legs
        hangedMan[5] = ("");                 //legs

        playerCounter = turn.firstTurn(player1, player2);
        if (playerCounter == 1){ 
            askSecretWord(player1);
            guessWord(player2, player1);
        }
        else {
            askSecretWord(player2);
            guessWord(player1, player2);
        }

    }

    private void askSecretWord(Player player){
        System.out.println("\nFirst player is " );
        System.out.println(player.name);
        System.out.println(player.name + ", please enter your secret word " );

        secretWord = player.sendPlayString().toLowerCase();
        secretWordarray = read.string2Char(secretWord);   
        guessingWordarray = new char[secretWordarray.length];   
        for (int i = 0; i < secretWordarray.length; i++){
            guessingWordarray[i] = ' ';                 
        }

    }

    private void guessWord(Player player, Player p2){
        String guess = "";
        do {
        System.out.println("\nYou have "+ hangmanParts + " attempts left" );
        System.out.println(player.name + ", please enter your guess: " );
        printHangMan();
        guess = player.sendPlayString();
        try{
            checkWord(guess.charAt(0));
            editHangedMan();
        } catch(Exception e) { 
            System.out.println("Enter 1 letter at a time please"); 
        }
    } while (gaming);
    printHangMan();
    checkWin(player, p2);
        
    }

    private void checkWin(Player p1, Player p2){
        if (hangmanParts == 0){
            System.out.println("*********" + p2.name + " WON!!!************");
            p1.losses++;
            p2.wins++;     
        } else {            
            p2.losses++;
            p1.wins++;             
            System.out.println("*********" + p1.name + " WON!!!************");            
        }
        System.out.println("Enter to continue");
        scanner.nextLine();

    }

    private void printHangMan(){  
        String word = "";
        System.out.println("******************");  
        System.out.println("   ---------- ");   

        for (int i = 0; i < 6; i++){
            System.out.println("   |       " + hangedMan[i]);                 
        }   
        System.out.println("---------------");     
        System.out.println("******************");  
        for (int i = 0; i < secretWordarray.length; i++){
            if (guessingWordarray[i] == ' '){ word += " ";
       
        }
            else {word += guessingWordarray[i];  }           
        }  
        System.out.println(word);  
        for (int i = 0; i < secretWordarray.length; i++){
            System.out.print("_");                 
        }
        System.out.println("");      
    }

    private void checkWord(char letter){
        int sameWord = 0; 
        int wordLen = secretWordarray.length;
        int letterPosition = secretWord.indexOf(letter); 

        if (letterPosition == -1 ){
            System.out.println("Not in word"); 
            hangmanParts--;
        }
        else {
            System.out.println("Good Job!"); 
            guessingWordarray[letterPosition] = letter;
            for (int i = 0; i < wordLen; i++){
                if (guessingWordarray[i] != ' ') sameWord++;
            }
            gaming = (wordLen == sameWord) ? false : true;

        }

    }

    private void editHangedMan(){
        switch(hangmanParts){
            case 0:
                hangedMan[4] = "/ \\"; 
                hangedMan[5] = "**********YOU DIED**********";
                gaming = false; 
            break;

            case 1:  
                hangedMan[4] = "/";               
            break;

            case 2:        
                hangedMan[3] = " |";        
            break;

            case 3:
                hangedMan[2] = "/|\\";                
            break;

            case 4:
                hangedMan[2] = "/|";                
            break;

            case 5:
                hangedMan[2]= "/";                 
            break;

            case 6:
                hangedMan[1] = " O";                
            break;

            case 7:
                hangedMan[0] = " |";
            break;

            default:
            System.out.println("Attempts left: " + hangmanParts); 

            break;
        }

    }

}

/*
 *          O  
 *         /|\
 *          | 
 *         / \
 * 
 */