
public class PlayerStatistics {

    public void showStats(){
        
        System.out.println("Player Stats");
                
    }

}
