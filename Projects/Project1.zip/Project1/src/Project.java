
public class Project{
    
    public static void main(String []args) {
        //Menu menu = new Menu();
        new Menu().play();
           
    }


}