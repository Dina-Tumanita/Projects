
public class HangMan {

    public void play(Player player1, Player player2) {
        System.out.println("\n****Welcome to Hangman!****");
        System.out.println(player1.name + " vs " + player2.name);
    }

}
