
abstract class Soldier {
    int lifepoints;
    int armor;
    int attackdmg;
    boolean alive = true;
    int dicethrows;
    String type;
    String spellAgainst;

    public Dice dice = new Dice();

    public void defend(int attackDMG, int finalArmor){
      System.out.println("Attack: "+ attackDMG );
      System.out.println("Armor: "+ finalArmor );
      if (attackDMG > armor ||attackDMG == armor ){
        this.lifepoints = this.lifepoints - attackDMG;
        if (this.lifepoints <= 0){
          this.alive = false;
        }
      }
      else {
        System.out.println("Not enough Attack Damage");
      }
      }

      public int attack(){
        System.out.println(this.type+ " will throw Dice for attack");
        return dice.isThrown(dicethrows, this.attackdmg);
      }

      public int armorSet(){
        System.out.println(this.type + " will throw Dice for armor");
        return dice.isThrown(dicethrows, this.armor);
      }

}

