
public class Player {
    private Piece x;
    private Piece y;
    private Piece empty;

}
