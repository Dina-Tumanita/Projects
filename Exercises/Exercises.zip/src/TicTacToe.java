
public class TicTacToe{

    private Board board;
    private Player p1; 
    private Player p2; 

    public TicTacToe(){
    
    }

    public void gaming(){
        
    }
}
