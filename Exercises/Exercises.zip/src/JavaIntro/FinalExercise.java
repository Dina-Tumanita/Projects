/*
Crear un método para escribir el perímetro y área de figuras geométricas. Este método debe de estar en la clase principal. 

Tener un menú con lo siguiente: 
Crear cuadrado
Crear Circulo
Crear Rectangulo
Crear Octagono
Imprimir Perimetro
Imprimir área 
Imprimir tipo de figura
salir

Crear una jerarquía de herencia para las figuras geométricas, y en la clase del menú principal, imprimir lo que se le solicita. 

*/

import java.util.Scanner

public class FinalExercise(){
    scanner = new Scanner(System.in);
}

